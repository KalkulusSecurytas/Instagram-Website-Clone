import React from 'react'
import "./Suggestion.css"
import { Avatar } from '@mui/material'

const Suggestion = () => {
  return (
    <div className='suggestons'>
        <div className='suggestions__title'>Suggestions for you</div>
        <div className='suggestions__usernames'>

        <div className='suggestions__username'>
            <div className='username__left'></div>
            <span className='avatar'>
                <Avatar>P</Avatar>
            </span>
            <div className='username__info'>
                <span className='username'>Puneet_star </span>
                <span className='relation'>New to Instagram</span>
            </div>

            <button className='follow__button'>Follow</button>
        </div>
        <div className='suggestions__username'>
            <div className='username__left'></div>
            <span className='avatar'>
                <Avatar>S</Avatar>
            </span>
            <div className='username__info'>
                <span className='username'>Shavet_reeee </span>
                <span className='relation'>New to Instagram</span>
            </div>

            <button className='follow__button'>Follow</button>
        </div>
        <div className='suggestions__username'>
            <div className='username__left'></div>
            <span className='avatar'>
                <Avatar>S</Avatar>
            </span>
            <div className='username__info'>
                <span className='username'>selmon_bhai </span>
                <span className='relation'>New to Instagram</span>
            </div>

            <button className='follow__button'>Follow</button>
        </div>
        <div className='suggestions__username'>
            <div className='username__left'></div>
            <span className='avatar'>
                <Avatar>S</Avatar>
            </span>
            <div className='username__info'>
                <span className='username'>Salu_bhai </span>
                <span className='relation'>New to Instagram</span>
            </div>

            <button className='follow__button'>Follow</button>
        </div>
        </div>
    </div>
  )
}

export default Suggestion